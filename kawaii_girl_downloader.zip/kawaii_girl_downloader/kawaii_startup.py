import json
import os

def site_sec():
    print("Hangi siteyi kullanmak istiyorsunuz?")
    print("1. Konachan (https://konachan.net/)")
    print("2. Yande.re (https://yande.re/)")
    site_secim = input("Seçiminizi yapın (1 veya 2): ")

    if site_secim == '1':
        return "konachan"
    elif site_secim == '2':
        return "yande.re"
    else:
        print("Geçersiz seçim. Varsayılan Konachan seçildi.")
        return "konachan"

def icerik_sec():
    print("\nİçerik türünü seçin:")
    print("1. Safe (Güvenli içerik)")
    print("2. Questionable (Şüpheli içerik)")
    print("3. Explicit (+18 içerik)")
    icerik_secim = input("Seçiminizi yapın (1, 2 veya 3): ")

    if icerik_secim == '1':
        return "safe"
    elif icerik_secim == '2':
        return "questionable"
    elif icerik_secim == '3':
        return "explicit"
    else:
        print("Geçersiz seçim. Varsayılan Safe seçildi.")
        return "safe"

def config_olustur():
    site = site_sec()
    rating = icerik_sec()

    save_path = input("\nGörsellerin kaydedileceği klasörün tam yolunu yazın (örnek: /home/kullanici/Resimler/.anime/): ").strip()

    tags = input("\nİndirmek istediğiniz etiketleri yazın (boş bırakabilirsiniz): ").strip()
    blacklist_tags = input("\nHariç tutmak istediğiniz etiketleri yazın (boş bırakabilirsiniz): ").strip()

    min_score = int(input("\nMinimum puan (score) filtresi (örn: 50): ") or 0)

    tarih_filtresi = input("\nTarih filtresi kullanılsın mı? (evet/hayır): ").strip().lower()
    if tarih_filtresi == "evet":
        year_from = int(input("Başlangıç yılı (örn: 2020): "))
        year_to = int(input("Bitiş yılı (örn: 2025): "))
        date_filter_enabled = True
    else:
        year_from = 2000
        year_to = 2100
        date_filter_enabled = False

    limit = int(input("\nBu oturumda indirilecek maksimum görsel sayısı (örn: 100): "))

    auto_download = input("\nOtomatik indirme açılsın mı? (evet/hayır): ").strip().lower() == "evet"
    multi_thread = input("Çoklu indirme (multithread) kullanılsın mı? (evet/hayır): ").strip().lower() == "evet"
    thread_count = int(input("Kullanılacak thread sayısı (örn: 5): ") or 5)

    proxy = input("\nProxy kullanmak istiyor musunuz? (örn: http://127.0.0.1:8080) (boş bırakabilirsiniz): ").strip()

    config = {
        "site": site,
        "tags": tags,
        "blacklist_tags": blacklist_tags,
        "min_score": min_score,
        "date_filter_enabled": date_filter_enabled,
        "date_from": year_from,
        "date_to": year_to,
        "limit_per_session": limit,
        "auto_download_enabled": auto_download,
        "multi_thread": multi_thread,
        "threads": thread_count,
        "proxy": proxy,
        "save_path": save_path,
        "rating": rating,
        "timeout_seconds": 10,
        "retry_attempts": 5,
        "organize_wallpapers": True,
        "search_enabled": True
    }

    with open('config.json', 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4, ensure_ascii=False)
    print("\nConfig dosyası başarıyla oluşturuldu: config.json")

if __name__ == "__main__":
    config_olustur()


