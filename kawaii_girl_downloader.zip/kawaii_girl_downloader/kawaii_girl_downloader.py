import os
import threading
import time
import requests
import json
from datetime import datetime
from urllib.parse import urlencode

def create_folder(path):
    if not os.path.exists(path):
        os.makedirs(path)

def load_config():
    if not os.path.exists('config.json'):
        print("Config dosyası bulunamadı! Önce startup.py'yi çalıştırın.")
        exit()
    with open('config.json', 'r', encoding='utf-8') as f:
        return json.load(f)

def load_downloaded_ids(save_path):
    file_path = os.path.join(save_path, "downloaded.txt")
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            return set(line.strip() for line in f)
    return set()

def save_downloaded_id(save_path, image_id):
    file_path = os.path.join(save_path, "downloaded.txt")
    with open(file_path, 'a', encoding='utf-8') as f:
        f.write(str(image_id) + "\n")

def search_images(config, page):
    base_url = {
        "konachan": "https://konachan.net/post.json?",
        "yande.re": "https://yande.re/post.json?"
    }.get(config['site'], "https://konachan.net/post.json?")

    params = {
        "limit": 100,
        "page": page,
        "tags": config['tags']
    }

    if config['rating'] in ['safe', 'explicit', 'questionable']:
        params["tags"] += f" rating:{config['rating']}"

    url = base_url + urlencode(params)
    print(f"Aranıyor: {url}")

    try:
        response = requests.get(url, timeout=config['timeout_seconds'], proxies={"http": config['proxy'], "https": config['proxy']} if config['proxy'] else None)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Hata: {response.status_code}")
            return []
    except Exception as e:
        print(f"Bağlantı hatası: {e}")
        return []

def download_image(session, url, save_path):
    try:
        local_filename = os.path.join(save_path, url.split("/")[-1])
        if not os.path.exists(local_filename):
            r = session.get(url, stream=True, timeout=20)
            if r.status_code == 200:
                with open(local_filename, 'wb') as f:
                    for chunk in r.iter_content(1024):
                        f.write(chunk)
                print(f"İndirildi: {local_filename}")
            else:
                print(f"Hata: {url}")
    except Exception as e:
        print(f"İndirme hatası: {url} | {e}")

def organize_wallpapers(save_path):
    print("Organizasyon yapılıyor...")
    organized_folder = os.path.join(save_path, "Organized")
    create_folder(organized_folder)
    for file in os.listdir(save_path):
        if file.endswith(('.jpg', '.jpeg', '.png', '.gif')):
            os.rename(os.path.join(save_path, file), os.path.join(organized_folder, file))
    print("Organizasyon tamamlandı.")

def filter_images_by_date(images, config):
    if not config['date_filter_enabled']:
        return images

    filtered = []
    for img in images:
        created_at = img.get('created_at')
        if not created_at:
            continue
        img_date = datetime.utcfromtimestamp(created_at)
        img_year = img_date.year
        if config['date_from'] <= img_year <= config['date_to']:
            filtered.append(img)
    return filtered

def start_download(config):
    create_folder(config['save_path'])
    session = requests.Session()
    proxies = {"http": config['proxy'], "https": config['proxy']} if config['proxy'] else None

    downloaded_ids = load_downloaded_ids(config['save_path'])

    downloaded = 0
    page = 1

    while downloaded < config['limit_per_session']:
        print(f"\nSayfa {page} aranıyor...")
        images = search_images(config, page)
        if not images:
            print("Daha fazla görsel bulunamadı.")
            break

        filtered_images = filter_images_by_date(images, config)
        if not filtered_images:
            print("Tarih filtresine uyan görsel bulunamadı.")
            page += 1
            continue

        download_jobs = []
        for img in filtered_images:
            if 'file_url' not in img or 'id' not in img:
                continue

            if str(img['id']) in downloaded_ids:
                print(f"Zaten indirilmiş: {img['id']}")
                continue

            if downloaded >= config['limit_per_session']:
                break

            url = img['file_url']
            if config['multi_thread']:
                t = threading.Thread(target=download_image, args=(session, url, config['save_path']))
                download_jobs.append(t)
                t.start()
            else:
                download_image(session, url, config['save_path'])

            save_downloaded_id(config['save_path'], img['id'])
            downloaded_ids.add(str(img['id']))
            downloaded += 1

        for t in download_jobs:
            t.join()

        page += 1

    if config['organize_wallpapers']:
        organize_wallpapers(config['save_path'])

    print(f"\nİndirme tamamlandı! Toplam indirilen görsel sayısı: {downloaded}")

if __name__ == "__main__":
    config = load_config()
    while True:
        start_download(config)
        if not config['auto_download_enabled']:
            break
        print(f"{config['auto_download_interval_hours']} saat sonra tekrar denenecek...")
        time.sleep(config['auto_download_interval_hours'] * 3600)


